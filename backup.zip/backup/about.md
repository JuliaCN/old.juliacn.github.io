---
layout: page
title: About
permalink: /about/
---

Hello, world!


---

Here's what the blog powered by:

[GitHub - Where softwares are built](https://github.com)

[Jekyll - An open, free, static framework for hacker's blogging](http://jekyllrb.com/)

[Disqus - Awesome and free commenting tool](https://disqus.com/)

[inlineDisqussions - Make Disqus inline](https://github.com/tsi/inlineDisqussions/)

[Mathjax - Rendering high quality LaTeX contents](https://www.mathjax.org/)





